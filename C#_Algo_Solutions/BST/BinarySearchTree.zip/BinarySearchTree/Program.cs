﻿using System;
using BinarySearchTree.Models;

namespace BinarySearchTree
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var list = new BST();
            var newNode = new Node(5);
            var newNode1 = new Node(10);
            var newNode2 = new Node(2);
            var newNode3 = new Node(3);
            var newNode4 = new Node(54);
            list.InsertAt(newNode);
            list.InsertAt(newNode1);
            list.InsertAt(newNode2);
            list.InsertAt(newNode3);
            list.InsertAt(newNode4);
            Console.WriteLine(list.Balance(list.Root));
            list.PrintValues(list.Root);
        }
    }
}
