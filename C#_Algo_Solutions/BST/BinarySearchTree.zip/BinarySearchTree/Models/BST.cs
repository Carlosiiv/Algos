using System;
using System.Runtime.InteropServices;
using BinarySearchTree.Models;

namespace BinarySearchTree.Models
{
    public class BST
    {
        public Node Root{get;set;}
        private int _height{get;set;} = 0;

        public int Height{
            get{
                
                return _Height(Root);
            }
        }
        private int _Height(Node runner){
            if(runner == null){
                return 0;
            }
            return Math.Max(_Height(runner.Left),_Height(runner.Right))+1;
        }   

        public bool Balance(Node node){
            if( node == null){
                return true;
            }
            else{
                int left = _Height(node.Left);
                int right = _Height(node.Right);

                if(Math.Abs(left-right) <= 1 && Balance(node.Left) && Balance(node.Right)){
                    return true;
                }
                else{
                    return false;
                }
            }
            
        }
        

        public BST(int val){
            Root = new Node(val);
        }
        public BST(){
            Root = null;
        }
        

        public BST InsertAt(Node newNode){
            if(Root == null){
                Root = newNode;
                return this;
            }
            else{
                var runner = Root;
                while(runner != null){
                    if(newNode.Val < runner.Val){
                        if(runner.Left == null){
                            runner.Left = newNode;
                            return this;
                        }
                        else{
                            runner = runner.Left;
                            continue;
                        }
                    }
                    else if (newNode.Val > runner.Val){
                        if(runner.Right == null){
                            runner.Right = newNode;
                            return this;
                        }
                        else{
                            runner = runner.Right;
                            continue;
                        }
                    }
                    else{
                        return this;
                    }
                }
                return this;
            }
        }
        public void PrintValues()
        {
            PrintValues(Root);
        }

        public void PrintValues(Node squirrel)
        {
            if(squirrel != null)
            {
                System.Console.WriteLine(squirrel.Val);
                PrintValues(squirrel.Left);
                PrintValues(squirrel.Right);
            }
        }
    }
}
    


